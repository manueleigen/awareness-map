document.addEventListener('DOMContentLoaded', () => {
    const container = document.getElementById('result');
    const engine = new QuizEngine(container, storyPoints);
    engine.start('intro');
});
