const storyPoints = [
    {
        id: "intro",
        type: "location-quiz",
        title: "Pick a location",
        question: "Wo ist walter?",
        maxDistance:1000,
        solution: {x: 150, y: 150},
        next: {
            right: "intro2",
            wrong: "fail-screen"
        }
    },{
        id: "intro2",
        type: "quiz",
        title: "content.intro.title",
        question: "content.intro.question",
        options: [
            { label: "content.intro.optionA", value: "a" },
            { label: "content.intro.optionB", value: "b" }
        ],
        solution: ["b"],
        next: {
            right: "select-drone-drop-off",
            wrong: "fail-screen"
        },
        minAnswers: 1,
        maxAnswers: 1
    },
    {
        id: "select-drone-drop-off",
        type: "point-selection-quiz",
        title: "content.location.title",
        question: "content.location.question",
        interactionLayerId: "map-layer",
        solution: ["point-1"],
        next: {
            right: "quiz-who-you-wanna-call",
            wrong: "fail-screen"
        },
        minSelection: 1,
        maxSelection: 1
    },
    {
        id: "quiz-who-you-wanna-call",
        type: "quiz",
        title: "content.call.title",
        question: "content.call.question",
        options: [
            { label: "content.call.optionA", value: "a" },
            { label: "content.call.optionB", value: "b" },
            { label: "content.call.optionC", value: "c" }
        ],
        solution: ["c"],
        next: {
            right: "win-screen",
            wrong: "fail-screen"
        },
        minAnswers: 1,
        maxAnswers: 1
    },
    {
        id: "win-screen",
        type: "info",
        title: "content.win.title",
        description: "content.win.description",
        continueButtonText: "content.common.restart",
        next: "intro"
    },
    {
        id: "fail-screen",
        type: "info",
        title: "content.fail.title",
        description: "content.fail.description",
        continueButtonText: "content.common.restart",
        next: "intro"
    }
];
