const content = {
    intro: {
        title: "Krisenstab-Challenge",
        question: "Was willst du machen?",
        optionA: "Informationen weiterleiten",
        optionB: "Drohne entsenden"
    },
    location: {
        title: "Einsatzort wählen",
        question: "Wähle den richtigen Ort auf der Karte aus (Klicke in die Mitte)."
    },
    call: {
        title: "Information weiterleiten",
        question: "An wen sollen die Informationen weitergeleitet werden?",
        optionA: "Einsatzkräfte",
        optionB: "Öffentlichkeit",
        optionC: "beide"
    },
    win: {
        title: "Gewonnen!",
        description: "You win, yay..."
    },
    fail: {
        title: "Fehlgeschlagen",
        description: "Das war leider die falsche Entscheidung."
    },
    common: {
        restart: "Nochmal von vorn"
    }
};
