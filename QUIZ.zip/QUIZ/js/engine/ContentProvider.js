class ContentProvider {
    static getText(path) {
        if (!path || typeof path !== 'string' || !path.startsWith('content.')) {
            return path;
        }

        const keys = path.split('.').slice(1);
        let current = content;

        for (const key of keys) {
            if (current && current[key] !== undefined) {
                current = current[key];
            } else {
                console.warn(`Content path not found: ${path}`);
                return path;
            }
        }

        return current;
    }
}
