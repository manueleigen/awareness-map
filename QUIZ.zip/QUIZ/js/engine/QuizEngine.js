class QuizEngine {
    constructor(container, storyPoints) {
        this.container = container;
        this.storyPoints = storyPoints;
        this.currentPoint = null;

        this.renderers = {
            'info': new InfoRenderer(container, (res) => this.handleAction(res)),
            'quiz': new QuizRenderer(container, (res) => this.handleAction(res)),
            'area-selection-quiz': new SelectionRenderer(container, (res) => this.handleAction(res)),
            'point-selection-quiz': new SelectionRenderer(container, (res) => this.handleAction(res)),
            'location-quiz': new LocationRenderer(container, (res) => this.handleAction(res))
        };
    }

    start(startId) {
        this.loadStoryPoint(startId);
    }

    loadStoryPoint(id) {
        this.currentPoint = this.storyPoints.find(p => p.id === id);
        if (!this.currentPoint) {
            console.error(`Story point ${id} not found.`);
            return;
        }

        const renderer = this.renderers[this.currentPoint.type];
        if (renderer) {
            renderer.render(this.currentPoint);
        } else {
            console.error(`No renderer for type ${this.currentPoint.type}`);
        }
    }

    handleAction(isCorrect) {
        let nextId;
        if (typeof this.currentPoint.next === 'string') {
            nextId = this.currentPoint.next;
        } else {
            nextId = isCorrect ? this.currentPoint.next.right : this.currentPoint.next.wrong;
        }

        this.loadStoryPoint(nextId);
    }
}
