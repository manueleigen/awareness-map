class SelectionRenderer extends BaseRenderer {
    constructor(container, onAction) {
        super(container, onAction);
        this.selectedIds = new Set();
    }

    render(storyPoint) {
        super.render(storyPoint);
        this.selectedIds.clear();

        this.renderDescription(storyPoint.question);

        const area = document.createElement('div');
        area.className = 'interaction-area';
        area.id = storyPoint.interactionLayerId;
        
        if (storyPoint.type === 'area-selection-quiz') {
            area.innerHTML = `
                <svg width="100%" height="100%" viewBox="0 0 300 300">
                    <polygon id="area-1" points="10,10 50,10 50,50 10,50" fill="#ccc" stroke="#333" />
                    <polygon id="area-2" points="100,100 200,100 200,200 100,200" fill="#ccc" stroke="#333" />
                </svg>
            `;
            area.querySelectorAll('polygon').forEach(poly => {
                poly.onclick = (e) => this.toggleSelection(poly, poly.id, storyPoint);
            });
        } else {
            area.innerHTML = `
                <div id="point-1" style="width:50px; height:50px; background:#ccc; position:absolute; left:20px; top:20px;">1</div>
                <div id="point-2" style="width:50px; height:50px; background:#ccc; position:absolute; left:200px; top:150px;">2</div>
            `;
            area.querySelectorAll('div').forEach(div => {
                div.onclick = (e) => this.toggleSelection(div, div.id, storyPoint);
            });
        }

        this.container.appendChild(area);

        this.renderButton('Auswahl bestätigen', () => {
            if (storyPoint.minSelection && this.selectedIds.size < storyPoint.minSelection) {
                alert(`Bitte wähle mindestens ${storyPoint.minSelection} Element(e).`);
                return;
            }
            const isCorrect = this.evaluate(storyPoint.solution);
            this.onAction(isCorrect);
        });
    }

    toggleSelection(element, id, storyPoint) {
        if (this.selectedIds.has(id)) {
            this.selectedIds.delete(id);
            element.style.fill = '#ccc';
            element.style.backgroundColor = '#ccc';
        } else {
            if (storyPoint.maxSelection && this.selectedIds.size >= storyPoint.maxSelection) return;
            this.selectedIds.add(id);
            element.style.fill = '#007bff';
            element.style.backgroundColor = '#007bff';
        }
    }

    evaluate(solution) {
        if (this.selectedIds.size !== solution.length) return false;
        return solution.every(id => this.selectedIds.has(id));
    }
}
