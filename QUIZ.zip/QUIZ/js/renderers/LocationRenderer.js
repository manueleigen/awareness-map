class LocationRenderer extends BaseRenderer {
    constructor(container, onAction) {
        super(container, onAction);
        this.selectedPoint = null;
    }

    render(storyPoint) {
        super.render(storyPoint);
        this.selectedPoint = null;

        this.renderDescription(storyPoint.question);

        const area = document.createElement('div');
        area.className = 'interaction-area';
        area.style.cursor = 'crosshair';
        area.onclick = (e) => this.setPoint(e, area);

        this.container.appendChild(area);

        this.renderButton('Ort bestätigen', () => {
            if (!this.selectedPoint) {
                alert('Bitte wähle zuerst einen Ort auf der Karte.');
                return;
            }
            const isCorrect = this.evaluate(storyPoint.solution, storyPoint.maxDistance);
            this.onAction(isCorrect);
        });
    }

    setPoint(e, area) {
        const rect = area.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        
        this.selectedPoint = { x, y };

        let marker = area.querySelector('.marker');
        if (!marker) {
            marker = document.createElement('div');
            marker.className = 'marker';
            marker.style.position = 'absolute';
            marker.style.width = '10px';
            marker.style.height = '10px';
            marker.style.borderRadius = '50%';
            marker.style.background = 'red';
            marker.style.transform = 'translate(-50%, -50%)';
            area.appendChild(marker);
        }
        marker.style.left = `${x}px`;
        marker.style.top = `${y}px`;
    }

    evaluate(solution, maxDistance) {
        if (!this.selectedPoint) return false;
        const dist = Math.sqrt(
            Math.pow(this.selectedPoint.x - solution.x, 2) +
            Math.pow(this.selectedPoint.y - solution.y, 2)
        );
        return dist <= maxDistance;
    }
}
