class InfoRenderer extends BaseRenderer {
    render(storyPoint) {
        super.render(storyPoint);
        this.renderDescription(storyPoint.description);
        this.renderButton(storyPoint.continueButtonText || 'Weiter', () => {
            this.onAction(true);
        });
    }
}
