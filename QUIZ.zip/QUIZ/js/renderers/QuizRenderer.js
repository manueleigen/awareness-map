class QuizRenderer extends BaseRenderer {
    constructor(container, onAction) {
        super(container, onAction);
        this.selectedValues = new Set();
    }

    render(storyPoint) {
        super.render(storyPoint);
        this.selectedValues.clear();

        this.renderDescription(storyPoint.question);

        const list = document.createElement('ul');
        list.className = 'options-list';

        storyPoint.options.forEach(opt => {
            const li = document.createElement('li');
            li.className = 'option-item';
            li.textContent = ContentProvider.getText(opt.label);
            li.onclick = () => this.toggleOption(li, opt.value, storyPoint);
            list.appendChild(li);
        });

        this.container.appendChild(list);

        this.renderButton('Weiter', () => {
            if (storyPoint.minAnswers && this.selectedValues.size < storyPoint.minAnswers) {
                alert(`Bitte wähle mindestens ${storyPoint.minAnswers} Option(en).`);
                return;
            }
            const isCorrect = this.evaluate(storyPoint.solution);
            this.onAction(isCorrect);
        });
    }

    toggleOption(element, value, storyPoint) {
        if (storyPoint.maxAnswers === 1) {
            this.selectedValues.clear();
            this.container.querySelectorAll('.option-item').forEach(el => el.classList.remove('selected'));
        }

        if (this.selectedValues.has(value)) {
            this.selectedValues.delete(value);
            element.classList.remove('selected');
        } else {
            if (storyPoint.maxAnswers && this.selectedValues.size >= storyPoint.maxAnswers) return;
            this.selectedValues.add(value);
            element.classList.add('selected');
        }
    }

    evaluate(solution) {
        if (this.selectedValues.size !== solution.length) return false;
        return solution.every(val => this.selectedValues.has(val));
    }
}
