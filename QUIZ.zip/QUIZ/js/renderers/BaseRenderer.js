class BaseRenderer {
    constructor(container, onAction) {
        this.container = container;
        this.onAction = onAction;
    }

    render(storyPoint) {
        this.container.innerHTML = '';
        this.renderTitle(storyPoint.title);
    }

    renderTitle(titlePath) {
        const title = document.createElement('h1');
        title.textContent = ContentProvider.getText(titlePath);
        this.container.appendChild(title);
    }

    renderDescription(descPath) {
        const desc = document.createElement('p');
        desc.textContent = ContentProvider.getText(descPath);
        this.container.appendChild(desc);
    }

    renderButton(textPath, callback) {
        const btn = document.createElement('button');
        btn.className = 'btn';
        btn.textContent = ContentProvider.getText(textPath);
        btn.onclick = callback;
        this.container.appendChild(btn);
    }
}
