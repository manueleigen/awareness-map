 Hey. I want to build a modular JS quiz engine. In a local window #result I want to generate content that guides the user through the quiz.  
 
content-types (suggestion): 
- info
	- story-point-id
	- title: path.to.title
	- description: path.to.description
	- continue-button-text: path.to.continue-button-text
	- next-story-point
	
- quiz 
	- story-point-id
	- title: path.to.title
	- question: path.to.question
	- options-array:
			- answer: path.to.answer
			- value
	- solution -> value-array
	- next-story-points
		- right: story-point-id
		- wrong: story-point-id
	- min-anwsers
	- max-anwsers
			
- area-selection-quiz ( user selects polygons in svg and can submit his selection -> returns polygon ids)
	- story-point-id
	- title: path.to.title
	- question
	- interaction-layer-id
	- solution -> ids-array
	- next-story-points
		- right: story-point-id
		- wrong: story-point-id
	- min-selection (optional)
	- max-selection (optional)
	
- point-selection-quiz ( user selects divs in DOM and can submit his selection -> returns div ids)
	- otherwise same as area-selection-quiz
	
- location-quiz ( user sets a point on map and can submit it)
	- story-point-id
	- title: path.to.title
	- question: path.to. question
	- interaction-layer-id
	- solution -> x/y coordinate
	- max-distance
	- next-story-points
		- right: story-point-id
		- wrong: story-point-id
		
Example: 
"Zum Krisenstab-Challenge-Ablauf ein Vorschlag:

Intro-Screen:
Wenn man die Challenge startet, wird man zuerst gefragt, was man machen will:
(a) Informationen weiterleiten ( falsch -> fail-screen )
oder
(b) Drohne entsenden ( richtig -> select-drone-drop-off )


select-drone-drop-off:
Wenn man „Drohne entsenden“ wählt, muss man den richtigen Ort auf der Karte auswählen. 
(falsch -> fail-screen )
( richtig -> quiz-who-you-wanna-call )

quiz-who-you-wanna-call:
Wenn das geschafft ist, kommt nochmal eine Frage im Stil eines Quiz:
Information weiterleiten an
(a) Einsatzkräfte (falsch -> fail-screen )
(b) Öffentlichkeit (falsch -> fail-screen )
(c) beide ( richtig -> win-screen )

win-screen:
"You win, yay..."